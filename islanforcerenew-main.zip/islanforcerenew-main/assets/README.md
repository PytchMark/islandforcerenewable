Place image or video assets in this folder.

Suggested files:
- hero-video.mp4 (replace HERO_VIDEO_URL in index.html)
- hero-poster.jpg (replace HERO_POSTER_URL in index.html)
